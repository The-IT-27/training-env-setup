Student Name: Marie
Batch Name: BatchA
Date of Setup: 2025-07-06
