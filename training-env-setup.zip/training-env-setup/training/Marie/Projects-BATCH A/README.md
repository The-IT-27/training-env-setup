Student Name: Marie
Batch Name: BATCH A
Date of Setup: 2025-06-29
